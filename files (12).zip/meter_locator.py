"""
Automatische Lokalisierung des Wasserzählers im Foto per klassischer
Bildverarbeitung (OpenCV Hough-Kreistransformation).

Der Zähler ist eine runde, helle Scheibe mit dunklem Rand -- ein gut
geeignetes Merkmal für Kreiserkennung, das sich von Wand, Rohr und
Hintergrund (z.B. Fahrrad) klar abhebt. In Tests mit echten Fotos war
der erste/stärkste Treffer von cv2.HoughCircles zuverlässig der Zähler,
auch bei unterschiedlichem Kameraabstand zwischen Bildreihen.

Wird einmal pro Bildreihe aufgerufen (nicht pro Einzelfoto), siehe preprocess.py.
"""
import cv2
import numpy as np

import config


def find_meter_crop_box(image_path: str) -> tuple[int, int, int, int] | None:
    """Sucht den Wasserzähler im Bild und gibt eine Crop-Box als
    (left, top, right, bottom) in Original-Pixelkoordinaten zurück.

    Gibt None zurück, wenn kein plausibler Kreis gefunden wurde
    (Aufrufer sollte dann auf "kein Crop" zurückfallen)."""
    img = cv2.imread(image_path)
    if img is None:
        return None
    h, w = img.shape[:2]

    # Für die Erkennung stark verkleinern (Performance) -- HoughCircles auf
    # voller Lumix-Auflösung (5472x3648) ist unnötig langsam.
    work_width = config.CIRCLE_DETECT_WIDTH
    scale = work_width / w
    small = cv2.resize(img, (work_width, int(h * scale)))
    sh, sw = small.shape[:2]

    gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
    gray = cv2.medianBlur(gray, 5)

    min_radius = int(sw * config.CIRCLE_MIN_RADIUS_FRACTION)
    max_radius = int(sw * config.CIRCLE_MAX_RADIUS_FRACTION)

    circles = cv2.HoughCircles(
        gray,
        cv2.HOUGH_GRADIENT,
        dp=1.2,
        minDist=sw * 0.3,
        param1=50,
        param2=40,
        minRadius=min_radius,
        maxRadius=max_radius,
    )

    if circles is None:
        return None

    # Ersten (stärksten) Treffer nehmen -- siehe Modul-Docstring.
    x, y, r = circles[0][0]
    x_full, y_full, r_full = x / scale, y / scale, r / scale

    box_r = r_full * config.CROP_MARGIN_FACTOR
    left = max(0, int(x_full - box_r))
    top = max(0, int(y_full - box_r))
    right = min(w, int(x_full + box_r))
    bottom = min(h, int(y_full + box_r))
    return (left, top, right, bottom)

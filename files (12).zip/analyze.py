"""
Auswertung der Wasserzähler-CSV: Verbrauchsberechnung, Visualisierung,
Erkennung von Unregelmäßigkeiten (nächtliche Grundlast als Leck-Indikator).

Voraussetzung: pandas, matplotlib installiert
    pip install pandas matplotlib

Aufruf: python analyze.py
"""
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

import config


def load_data() -> pd.DataFrame:
    df = pd.read_csv(config.OUTPUT_CSV)

    gesamt_anzahl = len(df)
    # Fehlerhafte API-Aufrufe und als unplausibel markierte Werte (siehe read_meter.py,
    # check_plausibility) ausschließen, bevor überhaupt Deltas berechnet werden.
    df = df[(df["lesbarkeit"] != "FEHLER") & (df["plausibel"] == "ja")].copy()
    verworfen = gesamt_anzahl - len(df)
    if verworfen > 0:
        print(f"Hinweis: {verworfen} von {gesamt_anzahl} Zeilen wegen Fehler/Unplausibilität "
              f"ausgeschlossen (siehe Spalte 'hinweis' in der CSV für Details).")

    df["zeitstempel"] = pd.to_datetime(df["zeitstempel"])
    df["gesamtwert_m3"] = pd.to_numeric(df["gesamtwert_m3"], errors="coerce")
    df = df.dropna(subset=["gesamtwert_m3"])
    df = df.sort_values("zeitstempel").reset_index(drop=True)
    return df


def compute_consumption(df: pd.DataFrame) -> pd.DataFrame:
    """Berechnet Verbrauch zwischen aufeinanderfolgenden Messungen (Liter pro Intervall
    und Liter pro Minute, um auch bei Lücken in den Aufnahmen vergleichbar zu bleiben)."""
    df["delta_m3"] = df["gesamtwert_m3"].diff()
    df["delta_minuten"] = df["zeitstempel"].diff().dt.total_seconds() / 60
    df["liter_pro_minute"] = (df["delta_m3"] * 1000) / df["delta_minuten"]

    # Sicherheitsnetz: load_data() filtert bereits über die 'plausibel'-Spalte aus
    # read_meter.py, hier trotzdem nochmal auf negative Deltas prüfen, falls die CSV
    # zwischenzeitlich von Hand bearbeitet wurde oder ältere Einträge ohne diese
    # Spalte enthält.
    df.loc[df["delta_m3"] < 0, ["delta_m3", "liter_pro_minute"]] = None

    df["stunde"] = df["zeitstempel"].dt.hour
    df["ist_nacht"] = df["stunde"].between(1, 5)  # 01:00-05:59 als "Nacht" definiert
    return df


def detect_anomalies(df: pd.DataFrame) -> dict:
    """Einfache Heuristiken zur Anomalie-Erkennung:
    - Grundlast: gibt es nachts durchgehend einen Mindestverbrauch > 0?
    - Nächtliche Spitzen: ungewöhnlich hohe Einzelentnahmen in der Nachtzeit."""
    nacht_df = df[df["ist_nacht"]].dropna(subset=["liter_pro_minute"])
    tag_df = df[~df["ist_nacht"]].dropna(subset=["liter_pro_minute"])

    results = {}
    if not nacht_df.empty:
        results["nacht_median_l_min"] = nacht_df["liter_pro_minute"].median()
        results["nacht_min_l_min"] = nacht_df["liter_pro_minute"].min()
        results["nacht_max_l_min"] = nacht_df["liter_pro_minute"].max()
        # Grundlast-Verdacht: wenn auch das Minimum nachts deutlich über 0 liegt,
        # läuft vermutlich durchgehend Wasser irgendwo (z.B. Leck, tropfender Hahn).
        results["grundlast_verdacht"] = results["nacht_min_l_min"] > 0.05  # Schwellwert ggf. anpassen
    if not tag_df.empty:
        results["tag_median_l_min"] = tag_df["liter_pro_minute"].median()

    return results


def plot_consumption(df: pd.DataFrame, output_path: str = "/home/claude/wasserzaehler/output/verbrauch.png"):
    fig, axes = plt.subplots(2, 1, figsize=(14, 9), sharex=True)

    # Plot 1: Absoluter Zählerstand über Zeit
    axes[0].plot(df["zeitstempel"], df["gesamtwert_m3"], color="#1f77b4", linewidth=1)
    axes[0].set_ylabel("Zählerstand (m³)")
    axes[0].set_title("Wasserzähler: Absoluter Stand")
    axes[0].grid(alpha=0.3)

    # Plot 2: Verbrauchsrate (Liter/Minute), Nachtbereiche hervorgehoben
    axes[1].plot(df["zeitstempel"], df["liter_pro_minute"], color="#d62728", linewidth=1)
    for _, row in df[df["ist_nacht"]].iterrows():
        axes[1].axvspan(row["zeitstempel"], row["zeitstempel"], color="navy", alpha=0.02)
    axes[1].set_ylabel("Verbrauch (Liter/Minute)")
    axes[1].set_title("Verbrauchsrate (Nachtstunden 01-06 Uhr leicht hervorgehoben)")
    axes[1].grid(alpha=0.3)
    axes[1].xaxis.set_major_formatter(mdates.DateFormatter("%d.%m %H:%M"))
    fig.autofmt_xdate()

    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    print(f"Plot gespeichert: {output_path}")


def main():
    df = load_data()
    if df.empty:
        print("Keine gültigen Daten in der CSV gefunden.")
        return

    df = compute_consumption(df)
    anomalies = detect_anomalies(df)

    print(f"\nZeitraum: {df['zeitstempel'].min()} bis {df['zeitstempel'].max()}")
    print(f"Anzahl Messpunkte: {len(df)}")
    print(f"Gesamtverbrauch im Zeitraum: {df['gesamtwert_m3'].iloc[-1] - df['gesamtwert_m3'].iloc[0]:.3f} m³\n")

    print("--- Anomalie-Check ---")
    for key, val in anomalies.items():
        print(f"  {key}: {val}")

    if anomalies.get("grundlast_verdacht"):
        print("\n  ACHTUNG: Durchgehende nächtliche Grundlast erkannt -> mögliches Leck.")
    else:
        print("\n  Keine durchgehende nächtliche Grundlast erkannt -> kein klares Leck-Signal.")

    plot_consumption(df)


if __name__ == "__main__":
    main()

# Wasserzähler-Auswertung (Lumix-Workflow)

## Workflow-Übersicht

```
SD-Karte (Lumix)
    -> manuell kopieren nach RAW_PHOTOS_DIR/reihe_<name>/   (ein Unterordner pro Bildreihe!)
    -> preprocess.py   (Crop via meter_locator.py + Resize, Pillow/OpenCV statt GIMP)
    -> read_meter.py   (Claude Vision API -> CSV, inkl. Plausibilitätsprüfung)
    -> analyze.py      (Plot + Anomalie-Check)
```

## Ordnerstruktur für Fotos

Da sich die Kameraposition zwischen Akkuwechseln leicht verschieben kann (Stativ
ist nicht fixiert), braucht jede Bildreihe ihren eigenen Unterordner:

```
raw_photos/
  reihe_2026-06-17/
    P1050965.JPG
    P1050966.JPG
    ...
  reihe_2026-06-20/
    P1060027.JPG
    ...
```

`preprocess.py` bestimmt den Crop-Bereich automatisch per Kreiserkennung
(`meter_locator.py`, OpenCV Hough-Transformation) einmalig anhand des ersten
Fotos jeder Reihe und wendet ihn auf alle weiteren Fotos derselben Reihe an.
Der Ordnername selbst ist frei wählbar, wichtig ist nur die Unterordner-Ebene.

## Setup

1. Pfade in `config.py` an dein System anpassen (RAW_PHOTOS_DIR etc.).
2. Python-Pakete installieren:
   ```
   pip install pillow opencv-python-headless numpy anthropic pandas matplotlib
   ```
3. API-Key setzen (PowerShell):
   ```
   $env:ANTHROPIC_API_KEY = "sk-ant-..."
   ```
   Für dauerhafte Einrichtung: `setx ANTHROPIC_API_KEY "sk-ant-..."` (neues Terminal nötig danach).

## Ablauf nach jedem SD-Kartenwechsel

```
python preprocess.py     # neue Fotos verkleinern/croppen
python read_meter.py     # neue Bilder an Claude schicken, CSV erweitern
python analyze.py        # Plot aktualisieren, Anomalien checken
```

Alle drei Skripte sind idempotent: bereits verarbeitete Fotos bzw. bereits
in der CSV vorhandene Bilder werden automatisch übersprungen. Mehrfaches
Ausführen ist also unkritisch.

## Bekannte Annahmen / TODOs

- **Plausibilitätsprüfung**: `read_meter.py` prüft jeden neuen Wert gegen den
  zuletzt als plausibel markierten Wert (Spalte `plausibel` in der CSV). Einzige
  Regel aktuell: der Zähler kann nicht rückwärts laufen (Monotonie-Check). Eine
  Obergrenze für die Verbrauchsrate (z.B. "nicht mehr als X Liter/Minute") gibt
  es bewusst noch nicht -- dafür fehlt noch eine belastbare Referenz aus echten
  Daten. Als unplausibel markierte Zeilen werden NICHT verworfen, sondern bleiben
  mit Hinweistext in der CSV stehen, damit man bei Bedarf das Originalfoto von
  Hand nachprüfen kann. `analyze.py` schließt diese Zeilen automatisch aus der
  Verbrauchsberechnung aus.
- **Crop**: Wird jetzt automatisch pro Bildreihe per Kreiserkennung bestimmt
  (siehe oben). In Tests mit zwei echten Fotos aus unterschiedlichen Reihen
  (unterschiedlicher Kameraabstand) hat die Erkennung beide Mal zuverlässig
  funktioniert. Falls eine Reihe doch nicht erkannt wird, fällt die Pipeline
  automatisch auf "kein Crop" zurück (`CROP_FALLBACK_TO_FULL_IMAGE = True`)
  und gibt eine Warnung in der Konsole aus -- die Reihe wird dann trotzdem
  verarbeitet, nur mit höheren Tokenkosten pro Bild. Falls die Erkennung bei
  einer bestimmten Reihe systematisch danebenliegt, lässt sich die Cache-Datei
  `.crop_box.txt` im jeweiligen Reihen-Unterordner löschen, um die Erkennung
  erneut anzustoßen, oder die Datei von Hand mit eigenen Koordinaten
  (`left,top,right,bottom`) befüllen.
- **Zähler-Bauform**: Ziffernrollen (m³) + Zeigerrad (Bruchteile). Der Prompt
  in `read_meter.py` ist darauf ausgelegt, beide Teile zu kombinieren. Sollte
  Claude beim Zeiger systematisch danebenliegen, ggf. nur den Ziffernwert für
  die Verbrauchsanalyse nutzen (Trend ist ohnehin wichtiger als Präzision).
- **Nachtdefinition**: aktuell 01:00–05:59 Uhr in `analyze.py`, anpassbar.
- **Grundlast-Schwellwert**: aktuell 0.05 l/min in `detect_anomalies()`,
  sollte nach den ersten echten Daten kalibriert werden (abhängig vom
  Hintergrundverbrauch von 21 Wohnungen, z.B. durch Kühlschränke/Heizungen
  mit Wasseranschluss etc. -- "echtes Null" ist bei 21 Einheiten unrealistisch).

## Dateien

- `config.py` – zentrale Pfade & Parameter
- `meter_locator.py` – automatische Zähler-Lokalisierung per OpenCV-Kreiserkennung
- `preprocess.py` – Bildvorverarbeitung (Crop pro Bildreihe, Resize, Komprimierung)
- `read_meter.py` – Claude Vision API Aufruf, Plausibilitätsprüfung, schreibt CSV
- `analyze.py` – Pandas/Matplotlib Auswertung & Anomalie-Heuristik

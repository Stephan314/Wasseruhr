"""
Liest Zählerstände aus den verarbeiteten Fotos via Claude Vision API
und schreibt sie als Zeilen in eine CSV-Datei.

Voraussetzung: ANTHROPIC_API_KEY als Umgebungsvariable gesetzt
    (Windows, PowerShell):  $env:ANTHROPIC_API_KEY = "sk-ant-..."
    (Windows, dauerhaft):   setx ANTHROPIC_API_KEY "sk-ant-..."

Aufruf: python read_meter.py
"""
import os
import csv
import json
import base64
import re
from datetime import datetime

import anthropic

import config


PROMPT = """Das ist ein Foto eines Wasserzählers (Itron Aquadis, Großzähler für einen Wohnblock).
Das Rollenzählwerk hat folgenden Aufbau:
1. SCHWARZE Ziffernrollen (links/Hauptteil) = volle Kubikmeter (m³).
2. ROTE Ziffernrollen (rechts daneben) = die ersten drei Nachkommastellen des
   Kubikmeterwerts, also Liter (z.B. rot "224" bedeutet 0,224 m³ = 224 Liter).
3. Ein kleines Zeigerrad rechts vom Rollenzählwerk (Skala "x0,0001 m³") für eine
   vierte Nachkommastelle. Dieses Zeigerrad ist NICHT nötig für die Verbrauchsanalyse
   und kann grob geschätzt werden -- wichtig sind nur die Ziffernrollen.

Der Gesamtwert ergibt sich durch Aneinanderhängen: schwarz "08147" + rot "224"
ergibt 8147,224 m³ (NICHT addieren, sondern als Dezimalstellen anhängen).

Lies die Ziffernrollen ab und antworte AUSSCHLIESSLICH mit einem JSON-Objekt,
ohne weiteren Text, ohne Markdown-Codeblock, in folgendem Format:

{
  "ziffern_schwarz": "<volle m³ von den schwarzen Rollen, z.B. 8147>",
  "ziffern_rot": "<Liter-Nachkommastellen von den roten Rollen, immer 3-stellig, z.B. 224>",
  "gesamtwert_m3": "<kombinierter Wert als Dezimalzahl, z.B. 8147.224>",
  "lesbarkeit": "<gut|mittel|schlecht>",
  "anmerkung": "<kurze Anmerkung, falls etwas unklar war, sonst leer>"
}

Wichtig: Falls einzelne Ziffern zwischen zwei Rollenstellungen stehen (Übergang),
nimm die Ziffer, die gerade im Fenster sichtbar ist, auch wenn sie leicht versetzt
wirkt. Falls etwas nicht eindeutig lesbar ist, gib deine beste Schätzung und setze
"lesbarkeit" entsprechend. Antworte NUR mit dem JSON-Objekt."""


def encode_image(path: str) -> str:
    with open(path, "rb") as f:
        return base64.standard_b64encode(f.read()).decode("utf-8")


def parse_timestamp_from_filename(fname: str) -> str:
    """Erwartet Format YYYYMMDD_HHMMSS.jpg (ggf. mit _N Suffix) und gibt ISO-String zurück."""
    stem = os.path.splitext(fname)[0]
    match = re.match(r"(\d{8})_(\d{6})", stem)
    if not match:
        return ""
    dt = datetime.strptime(match.group(1) + match.group(2), "%Y%m%d%H%M%S")
    return dt.isoformat()


def call_claude_vision(client: anthropic.Anthropic, image_path: str) -> dict:
    """Schickt ein Bild an Claude und parst die JSON-Antwort.
    Wirft bei Parse-Fehlern eine Exception (wird vom Aufrufer abgefangen)."""
    img_b64 = encode_image(image_path)
    response = client.messages.create(
        model=config.ANTHROPIC_MODEL,
        max_tokens=500,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/jpeg",
                            "data": img_b64,
                        },
                    },
                    {"type": "text", "text": PROMPT},
                ],
            }
        ],
    )
    text = response.content[0].text.strip()
    # Falls Claude trotz Anweisung Markdown-Fences liefert, diese entfernen
    text = re.sub(r"^```json\s*|\s*```$", "", text).strip()
    return json.loads(text)


def load_processed_filenames_from_csv() -> set:
    """Liest bereits in der CSV vorhandene Dateinamen, um doppelte API-Aufrufe zu vermeiden."""
    if not os.path.exists(config.OUTPUT_CSV):
        return set()
    with open(config.OUTPUT_CSV, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        return {row["dateiname"] for row in reader}


def load_last_plausible_value() -> float | None:
    """Liest die CSV und gibt den zuletzt eingetragenen PLAUSIBLEN Zählerstand zurück.
    Wichtig: nimmt absichtlich nicht einfach die letzte Zeile, sondern den letzten
    Wert mit plausibel == 'ja', damit ein einzelner Fehlwert nicht alle folgenden
    Werte fälschlich als 'unplausibel' markiert (Fehlerfortpflanzung vermeiden)."""
    if not os.path.exists(config.OUTPUT_CSV):
        return None
    last_value = None
    with open(config.OUTPUT_CSV, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get("plausibel") == "ja":
                try:
                    last_value = float(row["gesamtwert_m3"])
                except (ValueError, KeyError):
                    continue
    return last_value


def check_plausibility(neuer_wert: float, letzter_wert: float | None) -> tuple[str, str]:
    """Prüft die einzige harte physikalische Regel: der Zähler kann nicht rückwärts
    laufen. Gibt (plausibel_ja_nein, hinweis_text) zurück.
    Bewusst OHNE Obergrenze für die Verbrauchsrate -- dafür fehlt noch eine
    belastbare Referenz aus echten Daten (s. README/TODOs)."""
    if letzter_wert is None:
        return "ja", ""  # erster Wert überhaupt, nichts zum Vergleichen
    if neuer_wert < letzter_wert:
        diff = letzter_wert - neuer_wert
        return "nein", f"Wert kleiner als vorheriger ({letzter_wert} m³), Differenz -{diff:.3f} m³ -- vermutlich Lesefehler"
    return "ja", ""


def main():
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        print("FEHLER: Umgebungsvariable ANTHROPIC_API_KEY ist nicht gesetzt.")
        return

    client = anthropic.Anthropic(api_key=api_key)

    if not os.path.isdir(config.PROCESSED_DIR):
        print(f"Verzeichnis {config.PROCESSED_DIR} existiert nicht. Erst preprocess.py ausführen.")
        return

    already_done = load_processed_filenames_from_csv()
    all_files = sorted(
        f for f in os.listdir(config.PROCESSED_DIR)
        if f.lower().endswith(".jpg")
    )
    todo_files = [f for f in all_files if f not in already_done]

    if not todo_files:
        print("Keine neuen Bilder zur Verarbeitung. CSV ist aktuell.")
        return

    print(f"{len(todo_files)} neue Bilder werden an die Claude API gesendet...")

    letzter_plausibler_wert = load_last_plausible_value()
    if letzter_plausibler_wert is not None:
        print(f"  (Referenzwert aus bestehender CSV: {letzter_plausibler_wert} m³)")

    file_exists = os.path.exists(config.OUTPUT_CSV)
    with open(config.OUTPUT_CSV, "a", encoding="utf-8", newline="") as f:
        fieldnames = [
            "dateiname", "zeitstempel", "ziffern_schwarz", "ziffern_rot",
            "gesamtwert_m3", "lesbarkeit", "plausibel", "hinweis", "anmerkung",
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()

        for i, fname in enumerate(todo_files, 1):
            img_path = os.path.join(config.PROCESSED_DIR, fname)
            timestamp = parse_timestamp_from_filename(fname)
            print(f"  [{i}/{len(todo_files)}] {fname} ...", end=" ")
            try:
                result = call_claude_vision(client, img_path)
                neuer_wert = float(result.get("gesamtwert_m3", "nan"))
                plausibel, hinweis = check_plausibility(neuer_wert, letzter_plausibler_wert)

                writer.writerow({
                    "dateiname": fname,
                    "zeitstempel": timestamp,
                    "ziffern_schwarz": result.get("ziffern_schwarz", ""),
                    "ziffern_rot": result.get("ziffern_rot", ""),
                    "gesamtwert_m3": result.get("gesamtwert_m3", ""),
                    "lesbarkeit": result.get("lesbarkeit", ""),
                    "plausibel": plausibel,
                    "hinweis": hinweis,
                    "anmerkung": result.get("anmerkung", ""),
                })
                f.flush()  # nach jedem Bild sichern, falls Skript abbricht

                status = "OK" if plausibel == "ja" else "UNPLAUSIBEL"
                print(f"{status} -> {neuer_wert} m³ ({result.get('lesbarkeit', '?')})"
                      + (f" -- {hinweis}" if hinweis else ""))

                # Referenzwert nur bei plausiblen Werten weiterführen, damit ein
                # einzelner Fehlwert nicht die Prüfung der Folgebilder verfälscht
                if plausibel == "ja":
                    letzter_plausibler_wert = neuer_wert

            except Exception as e:
                print(f"FEHLER: {e}")
                writer.writerow({
                    "dateiname": fname,
                    "zeitstempel": timestamp,
                    "ziffern_schwarz": "", "ziffern_rot": "",
                    "gesamtwert_m3": "", "lesbarkeit": "FEHLER",
                    "plausibel": "nein", "hinweis": "API-Fehler oder Parse-Fehler",
                    "anmerkung": str(e),
                })
                f.flush()

    print(f"\nFertig. Ergebnisse in {config.OUTPUT_CSV}")


if __name__ == "__main__":
    main()
